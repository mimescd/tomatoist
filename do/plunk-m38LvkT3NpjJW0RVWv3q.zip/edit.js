angular.module("todo").directive("edit", ['$document',  function($document) {
  return {
    link: function(scope, elem, attr) {
      var mousedown = function() {
        
        scope.test = "why"
        //alert('please')
        elem.parent().children()[1].setAttribute("ng-show", true)
        console.log(elem.parent().children()[1].getAttribute("ng-show"))
      };
      elem.bind("click", mousedown)
    }
  }
}])